<template>
  <div>
    <x-header :left-options="{showBack: false}">兴盛优选--商品列表</x-header>
    <div class="shop">
      <div class="shop-header">
        <span class="myshop">我的店铺</span>
        <!--<span class="recommend-num">今日推送：xx 次</span>-->
      </div>
      <div class="shop-body">
        <span class="shop-title">{{ shop.shop_name }}</span>
        <x-button class="shop-recommend" @click.native="pushShop()">推送店铺</x-button>
      </div>
    </div>
    <group title="可推送的商品">
      <cell-box class="goods-list" v-for="(goods, index) in goodsData">
        <flexbox>
          <flexbox-item :span="1/3" class="pic">
            <img :src="goods.ad_image" class="good-pic">
          </flexbox-item>
          <flexbox-item :span="2/3" class="desc">
            <span class="goods-title">{{ goods.name }}</span>
            <p class="goods-info">{{ goods.subtitle }}</p>
            <x-button  class="goods-recommend" @click.native="pushGoods(goods.product_id)">推送</x-button>
            <span class="discount-price">尖叫价：￥ <i>{{ goods.sale_price}}</i></span>
            <span class="origin-price">原价：￥ <i>{{ goods.org_price }}</i></span>
          </flexbox-item>
        </flexbox>
      </cell-box>
    </group>
  </div>
</template>

<script>
  import { Flexbox, FlexboxItem, Group, CellBox, XButton, XHeader, LoadingPlugin, Panel } from 'vux';
  import Vue from 'vue';
  import VueCookie from 'vue-cookie';

  Vue.use(LoadingPlugin);
  Vue.use(VueCookie);

  export default {
    name: 'recommend',
    components: {
      Group,
      CellBox,
      XButton,
      XHeader,
      Panel,
      Flexbox,
      FlexboxItem,
    },
    data() {
      return {
        goodsData: [],
        shop: {},
      };
    },
    created() {
      this.$vux.loading.show({
        text: 'Loading',
      });
      this.$http.get('user/info/').then((response) => {
        this.shop = response.data.data;
        console.log(this.shop);
      });
      this.$http.get('product/info/').then((response) => {
        const data = response.data.data;
        this.goodsData = data;
        this.$vux.loading.hide();
      }, () => {
        this.$vux.loading.hide();
      });
    },
    methods: {
      pushShop() {
        this.$http.get('product/push-shop/').then(() => {
          // do nothing
          console.log(1);
        });
      },
      pushGoods(goodsid) {
        this.$http.get(`product/push-by-shop?product_id=${goodsid}`).then(() => {
          // do nothing
          console.log(2);
        });
      },
    },
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .recommend {
    padding: 0 17px;
  }
  .shop {
    padding:0 17px;
    font-size:14px;
    color: #333;
    border-bottom: 1px solid #ccc;
    padding-bottom: 22px;
  }
  .shop-header {
    width: 100%;
    height: 40px;
    line-height: 40px;
  }
  .myshop {
    float: left;
    color: #888;
  }
  .recommend-num {
    float: right;
  }
  .shop-body {
    width: 100%;
    height: 30px;
    line-height: 40px;
  }
  .shop-title {
    float: left;
    height:30px;
    line-height:30px;
    font-size: 14px;
    font-weight:bold;
  }
  .shop-recommend {
    float: right;
    height: 20px;
    line-height: 17px;
    width: 75px;
    background-color: #29A529;
    color: #fff;
    border-radius: 5px;
    padding: 2px 5px;
    margin-top: 3px;
    text-align: center;
    font-size: 14px;
  }
  .goods-list {
    position: relative;
  }
  .pic {
    width: 100%;
    height:60px;
    overflow: hidden;
  }
  .desc {
    width:100%;
    height:90px;
    overflow: hidden;
    position: relative;
  }
  .good-pic {
    width: 100%;
  }
  .goods-title {
    font-size: 14px;
    font-weight:bold;
    color: #333;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
    max-width:180px;
  }
  .goods-info {
    font-size: 12px;
    color: #888;
    line-height: 20px;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
  }
  .goods-recommend {
    height: 22px;
    line-height: 23px;
    background-color: #29A529;
    width: 65px;
    position: absolute;
    right: 17px;
    bottom: 5px;
    font-size: 12px;
    color: #fff;
  }
  .origin-price {
    position: absolute;
    font-size: 12px;
    height: 20px;
    line-height: 20px;
    left: 0px;
    bottom:5px;
  }
  .origin-price i{
    font-style: normal;
    text-decoration: line-through;
  }
  .discount-price {
    position: absolute;
    font-size: 16px;
    height: 20px;
    line-height: 20px;
    left: 0px;
    bottom:28px;
  }
  .discount-price i {
    font-style: normal;
    color: #ff0000;
  }
</style>
